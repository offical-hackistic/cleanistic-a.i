import React from 'react';
import { EstimatorDemo } from '@/components/EstimatorDemo';

const Demo = () => {
  return <EstimatorDemo />;
};

export default Demo;